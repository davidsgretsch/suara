(function($){
  $(function(){

    $('.button-collapse').sideNav({
		menuWidth: 270,
		edge: 'right'
	});
    $('.parallax').parallax();

  }); // end of document ready
})(jQuery); // end of jQuery name space