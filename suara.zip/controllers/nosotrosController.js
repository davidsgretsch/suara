app.controller('nosotrosController', function ($scope){
	
	$scope.title = "Nosotros";

	$(document).ready(function(){
    	$('.materialboxed').materialbox();
  	});

});