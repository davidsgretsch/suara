app.controller('destinosController', function ($scope){
	
	$scope.title = "Destinos";
	
});